package kr.co.ezen;

public class custVO {
	private String cust_name;
	private int cust_age;
	private int cust_num;
	
	public custVO() {
		
	}
	public custVO(int cust_num, String cust_name, int cust_age) {
		this.cust_num = cust_num;
		this.cust_name = cust_name;
		this.cust_age = cust_age;
	}

	// getter & setter
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public int getCust_age() {
		return cust_age;
	}
	public void setCust_age(int cust_age) {
		this.cust_age = cust_age;
	}
	public int getCust_num() {
		return cust_num;
	}
	public void setCust_num(int cust_num) {
		this.cust_num = cust_num;
	}

}
